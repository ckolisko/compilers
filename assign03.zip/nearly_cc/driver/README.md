This directory is for the "driver" code: command line options,
main(), Unit, Function, etc. Utility code such as DebugVar
and the cpputil:: functions go here as well.
